"""
Escribe un programa que calcula la longitud de un 
string introducido por teclado en la consola
"""
str_val = input("Introduzca valor para ver su longitud: \n")

print("Longitud de {}: {}".format(str_val, len(str_val)))