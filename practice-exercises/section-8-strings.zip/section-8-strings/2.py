"""
Escribe un programa que solicite tu nombre y realice un saludo personalizado, 
deseando un buen día.
Procurad tener en cuenta el salto de línea para el texto que se introduce
"""
name = input("Introduzca su nombre para recibir un saludo personalizado: \n")

print("Buenos días {} :) :)".format(name))
