"""
Escribe un programa donde a vamos a mostrar un mensaje similar al siguiente. 
Podeís usar todos los print, caracteres de escape o lo necesario para mostrarlo, 
intentando hacerlo de la misma manera.
"""
print("===========================================================")
print("\t\tAHORCADO - OPCIONES DEL JUEGO")
print("===========================================================")
print("1) Jugar a acertar una palabra aleatoria.")
print("2) Jugar a acertar cinco palabras aleatorias.")
print("3) Jugar a acertar una palabra de un tema seleccionado")
print("4) Jugar a acertar cincos palabras de un tema seleccionado")
print("5) Salir.")
print("===========================================================")
